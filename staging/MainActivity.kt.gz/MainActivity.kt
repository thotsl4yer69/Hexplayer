package com.mazlabz.hexplayer

import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.mazlabz.hexplayer.model.CardAction
import com.mazlabz.hexplayer.model.CardMapping
import com.mazlabz.hexplayer.model.MediaPlayer
import com.mazlabz.hexplayer.model.PlayerState
import com.mazlabz.hexplayer.model.SpotifyDevice
import com.mazlabz.hexplayer.network.HexPlayerClient
import com.mazlabz.hexplayer.network.HomeAssistantClient
import com.mazlabz.hexplayer.nfc.NfcTools
import com.mazlabz.hexplayer.storage.SecureSettings
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private enum class Tab { DASHBOARD, CARDS, SPEAKERS, SETTINGS }
    private enum class NfcMode { IDLE, SCAN, WRITE }

    private lateinit var settings: SecureSettings
    private val executor = Executors.newSingleThreadExecutor()
    private var adapter: NfcAdapter? = null

    @Volatile private var nfcMode = NfcMode.IDLE
    @Volatile private var expectedWriteUid = ""

    private var tab by mutableStateOf(Tab.DASHBOARD)
    private var message by mutableStateOf("Ready")
    private var hexOnline by mutableStateOf(false)
    private var haOnline by mutableStateOf(false)
    private var cards by mutableStateOf<List<CardMapping>>(emptyList())
    private var devices by mutableStateOf<List<SpotifyDevice>>(emptyList())
    private var speakers by mutableStateOf<List<MediaPlayer>>(emptyList())
    private var playerState by mutableStateOf<PlayerState?>(null)

    private var hexUrl by mutableStateOf("http://hexplayer.local:8787")
    private var apiKey by mutableStateOf("")
    private var haUrl by mutableStateOf("http://homeassistant.local:8123")
    private var haToken by mutableStateOf("")
    private var selectedDeviceId by mutableStateOf("")

    private var editUid by mutableStateOf("")
    private var editName by mutableStateOf("")
    private var editType by mutableStateOf("spotify")
    private var editUri by mutableStateOf("")
    private var editDeviceId by mutableStateOf("")
    private var editEntityId by mutableStateOf("")
    private var editMediaId by mutableStateOf("")
    private var editMediaType by mutableStateOf("music")
    private var editDomain by mutableStateOf("")
    private var editService by mutableStateOf("")
    private var editEventType by mutableStateOf("")
    private var editData by mutableStateOf("{}")

    private var speakerMediaId by mutableStateOf("")
    private var speakerMediaType by mutableStateOf("music")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SecureSettings(this)
        adapter = NfcAdapter.getDefaultAdapter(this)
        hexUrl = settings.getUrl("hex", hexUrl)
        apiKey = settings.getSecret("api_key")
        haUrl = settings.getUrl("ha", haUrl)
        haToken = settings.getSecret("ha_token")

        setContent {
            MaterialTheme { HexPlayerApp() }
        }
        refreshAll()
    }

    override fun onResume() {
        super.onResume()
        adapter?.enableReaderMode(
            this,
            { tag -> handleTag(tag) },
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B,
            null,
        )
    }

    override fun onPause() {
        adapter?.disableReaderMode(this)
        super.onPause()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun handleTag(tag: Tag) {
        val uid = NfcTools.uid(tag)
        when (nfcMode) {
            NfcMode.IDLE -> Unit
            NfcMode.SCAN -> {
                nfcMode = NfcMode.IDLE
                runOnUiThread {
                    resetEditor(uid)
                    message = "Card detected: $uid"
                    tab = Tab.CARDS
                }
            }
            NfcMode.WRITE -> {
                if (uid != expectedWriteUid) {
                    runOnUiThread { message = "Wrong card. Expected $expectedWriteUid, saw $uid" }
                    return
                }
                nfcMode = NfcMode.IDLE
                val result = NfcTools.writeHexPlayerUri(tag, uid)
                runOnUiThread {
                    message = result.fold(
                        onSuccess = { "NFC programmed: hexplayer://card/$uid" },
                        onFailure = { "NFC write failed: ${it.message}" },
                    )
                }
            }
        }
    }

    private fun hexClient() = HexPlayerClient(hexUrl, apiKey)
    private fun haClient() = HomeAssistantClient(haUrl, haToken)

    private fun refreshAll() {
        executor.execute {
            var hOk = false
            var aOk = false
            var newCards = emptyList<CardMapping>()
            var newDevices = emptyList<SpotifyDevice>()
            var newSpeakers = emptyList<MediaPlayer>()
            var newState: PlayerState? = null
            val errors = mutableListOf<String>()

            try {
                val client = hexClient()
                hOk = client.health()
                if (apiKey.isNotBlank()) {
                    newCards = client.cards()
                    newDevices = client.spotifyDevices()
                    newState = client.playerState()
                }
            } catch (exc: Exception) {
                errors += "HexPlayer: ${exc.message}"
            }

            if (haToken.isNotBlank()) {
                try {
                    val client = haClient()
                    aOk = client.health()
                    newSpeakers = client.mediaPlayers()
                } catch (exc: Exception) {
                    errors += "Home Assistant: ${exc.message}"
                }
            }

            runOnUiThread {
                hexOnline = hOk
                haOnline = aOk
                cards = newCards
                devices = newDevices
                speakers = newSpeakers
                playerState = newState
                if (selectedDeviceId.isBlank()) selectedDeviceId = devices.firstOrNull { it.active }?.id.orEmpty()
                message = if (errors.isEmpty()) "Synced" else errors.joinToString(" | ")
            }
        }
    }

    private fun resetEditor(uid: String = "") {
        editUid = uid
        editName = ""
        editType = "spotify"
        editUri = ""
        editDeviceId = ""
        editEntityId = ""
        editMediaId = ""
        editMediaType = "music"
        editDomain = ""
        editService = ""
        editEventType = ""
        editData = "{}"
    }

    private fun loadEditor(card: CardMapping) {
        editUid = card.uid
        editName = card.name
        editType = card.action.type
        editUri = card.action.uri
        editDeviceId = card.action.deviceId
        editEntityId = card.action.entityId
        editMediaId = card.action.mediaContentId
        editMediaType = card.action.mediaContentType
        editDomain = card.action.domain
        editService = card.action.service
        editEventType = card.action.eventType
        editData = card.action.dataJson
    }

    private fun currentAction(): CardAction {
        if (editData.isNotBlank()) JSONObject(editData)
        return CardAction(
            type = editType,
            uri = editUri.trim(),
            deviceId = editDeviceId.trim(),
            entityId = editEntityId.trim(),
            mediaContentId = editMediaId.trim(),
            mediaContentType = editMediaType.trim().ifBlank { "music" },
            domain = editDomain.trim(),
            service = editService.trim(),
            eventType = editEventType.trim(),
            dataJson = editData.ifBlank { "{}" },
        )
    }

    private fun saveCard() {
        if (editUid.isBlank()) {
            message = "Scan a card first"
            return
        }
        val action = try { currentAction() } catch (exc: Exception) {
            message = "Invalid JSON data: ${exc.message}"
            return
        }
        val validation = when (action.type) {
            "spotify" -> if (!action.uri.startsWith("spotify:")) "Spotify URI must start with spotify:" else null
            "ha_media" -> if (!action.entityId.startsWith("media_player.") || action.mediaContentId.isBlank()) "Choose a speaker and media item" else null
            "ha_service" -> if (action.domain.isBlank() || action.service.isBlank()) "Domain and service are required" else null
            "ha_event" -> if (action.eventType.isBlank()) "Event type is required" else null
            else -> "Unsupported action type"
        }
        if (validation != null) {
            message = validation
            return
        }
        val card = CardMapping(editUid, editName.trim(), action)
        executor.execute {
            try {
                hexClient().upsert(card)
                runOnUiThread { message = "Saved ${card.uid}" }
                refreshAll()
            } catch (exc: Exception) {
                runOnUiThread { message = "Save failed: ${exc.message}" }
            }
        }
    }

    private fun deleteCard(uid: String) {
        executor.execute {
            try {
                hexClient().delete(uid)
                runOnUiThread { resetEditor(); message = "Deleted $uid" }
                refreshAll()
            } catch (exc: Exception) {
                runOnUiThread { message = "Delete failed: ${exc.message}" }
            }
        }
    }

    private fun triggerCard(uid: String) {
        executor.execute {
            try {
                hexClient().trigger(uid)
                runOnUiThread { message = "Triggered $uid" }
            } catch (exc: Exception) {
                runOnUiThread { message = "Trigger failed: ${exc.message}" }
            }
        }
    }

    private fun spotify(command: String) {
        executor.execute {
            try {
                hexClient().spotifyControl(command, selectedDeviceId)
                runOnUiThread { message = "Spotify: $command" }
                Thread.sleep(350)
                try {
                    val state = hexClient().playerState()
                    runOnUiThread { playerState = state }
                } catch (_: Exception) { }
            } catch (exc: Exception) {
                runOnUiThread { message = "Spotify control failed: ${exc.message}" }
            }
        }
    }

    private fun haService(domain: String, service: String, data: JSONObject, success: String) {
        executor.execute {
            try {
                haClient().service(domain, service, data)
                runOnUiThread { message = success }
                refreshAll()
            } catch (exc: Exception) {
                runOnUiThread { message = "Home Assistant failed: ${exc.message}" }
            }
        }
    }

    private fun saveSettings() {
        settings.putUrl("hex", hexUrl)
        settings.putSecret("api_key", apiKey)
        settings.putUrl("ha", haUrl)
        settings.putSecret("ha_token", haToken)
        message = "Settings saved"
        refreshAll()
    }

    private fun provisionHomeAssistant() {
        if (haUrl.isBlank() || haToken.isBlank()) {
            message = "Home Assistant URL and token are required"
            return
        }
        executor.execute {
            try {
                hexClient().provisionHomeAssistant(haUrl, haToken)
                runOnUiThread { message = "Home Assistant credentials provisioned to HexPlayer" }
            } catch (exc: Exception) {
                runOnUiThread { message = "Provisioning failed: ${exc.message}" }
            }
        }
    }

    @Composable
    private fun HexPlayerApp() {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text("HEXPLAYER", style = MaterialTheme.typography.headlineMedium)
            Text(message, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TabButton("Player", Tab.DASHBOARD)
                TabButton("Cards", Tab.CARDS)
                TabButton("Speakers", Tab.SPEAKERS)
                TabButton("Settings", Tab.SETTINGS)
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            when (tab) {
                Tab.DASHBOARD -> DashboardScreen()
                Tab.CARDS -> CardsScreen()
                Tab.SPEAKERS -> SpeakersScreen()
                Tab.SETTINGS -> SettingsScreen()
            }
        }
    }

    @Composable
    private fun TabButton(label: String, target: Tab) {
        if (tab == target) Button(onClick = { tab = target }) { Text(label) }
        else TextButton(onClick = { tab = target }) { Text(label) }
    }

    @Composable
    private fun DashboardScreen() {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("Connections", style = MaterialTheme.typography.titleMedium)
                    Text("HexPlayer: ${if (hexOnline) "online" else "offline"}")
                    Text("Home Assistant: ${if (haOnline) "online" else "offline / not configured"}")
                    Text("Registered cards: ${cards.size}")
                    Button(onClick = { refreshAll() }) { Text("Refresh") }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Now playing", style = MaterialTheme.typography.titleMedium)
                    Text(playerState?.title ?: "Nothing reported")
                    if (!playerState?.artists.isNullOrEmpty()) Text(playerState!!.artists.joinToString(", "))
                    Text(playerState?.device ?: "No active Spotify device")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { spotify("previous") }) { Text("Prev") }
                        Button(onClick = { spotify(if (playerState?.playing == true) "pause" else "play") }) { Text(if (playerState?.playing == true) "Pause" else "Play") }
                        Button(onClick = { spotify("next") }) { Text("Next") }
                    }
                    if (devices.isNotEmpty()) {
                        Text("Target Spotify device")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            devices.forEach { device ->
                                TextButton(onClick = { selectedDeviceId = device.id }) {
                                    Text(if (selectedDeviceId == device.id) "[${device.name}]" else device.name)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun CardsScreen() {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    nfcMode = NfcMode.SCAN
                    message = "Tap the NFC card you want to configure"
                }) { Text("Scan new card") }
                TextButton(onClick = { resetEditor() }) { Text("Clear editor") }
            }
            if (adapter == null) Text("This phone has no NFC hardware; remote control still works.")

            cards.forEach { card ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(card.name.ifBlank { card.uid }, style = MaterialTheme.typography.titleSmall)
                        Text("${card.uid} · ${card.action.type}")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { loadEditor(card) }) { Text("Edit") }
                            TextButton(onClick = { triggerCard(card.uid) }) { Text("Test") }
                        }
                    }
                }
            }

            if (editUid.isNotBlank()) {
                HorizontalDivider()
                Text("Card editor", style = MaterialTheme.typography.titleLarge)
                Text("UID: $editUid")
                OutlinedTextField(editName, { editName = it }, label = { Text("Card name") }, modifier = Modifier.fillMaxWidth())
                Text("Action")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ActionButton("Spotify", "spotify")
                    ActionButton("Speaker", "ha_media")
                    ActionButton("HA service", "ha_service")
                    ActionButton("HA event", "ha_event")
                }

                when (editType) {
                    "spotify" -> {
                        OutlinedTextField(editUri, { editUri = it }, label = { Text("Spotify URI") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(editDeviceId, { editDeviceId = it }, label = { Text("Spotify device ID (optional)") }, modifier = Modifier.fillMaxWidth())
                        if (devices.isNotEmpty()) {
                            Row(Modifier.horizontalScroll(rememberScrollState())) {
                                devices.forEach { d -> TextButton(onClick = { editDeviceId = d.id }) { Text(d.name) } }
                            }
                        }
                    }
                    "ha_media" -> {
                        OutlinedTextField(editEntityId, { editEntityId = it }, label = { Text("media_player entity") }, modifier = Modifier.fillMaxWidth())
                        if (speakers.isNotEmpty()) {
                            Row(Modifier.horizontalScroll(rememberScrollState())) {
                                speakers.forEach { s -> TextButton(onClick = { editEntityId = s.entityId }) { Text(s.name) } }
                            }
                        }
                        OutlinedTextField(editMediaId, { editMediaId = it }, label = { Text("Media content ID / URI") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(editMediaType, { editMediaType = it }, label = { Text("Media content type") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(editData, { editData = it }, label = { Text("Extra service data JSON") }, modifier = Modifier.fillMaxWidth())
                    }
                    "ha_service" -> {
                        OutlinedTextField(editDomain, { editDomain = it }, label = { Text("Domain (e.g. script)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(editService, { editService = it }, label = { Text("Service (e.g. turn_on)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(editEntityId, { editEntityId = it }, label = { Text("Entity ID (optional)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(editData, { editData = it }, label = { Text("Service data JSON") }, modifier = Modifier.fillMaxWidth())
                    }
                    "ha_event" -> {
                        OutlinedTextField(editEventType, { editEventType = it }, label = { Text("Event type") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(editData, { editData = it }, label = { Text("Event data JSON") }, modifier = Modifier.fillMaxWidth())
                    }
                }

                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { saveCard() }) { Text("Save mapping") }
                    Button(onClick = {
                        expectedWriteUid = editUid
                        nfcMode = NfcMode.WRITE
                        message = "Retap $editUid to write its HexPlayer NDEF label"
                    }) { Text("Program NFC") }
                    TextButton(onClick = { triggerCard(editUid) }) { Text("Test action") }
                    TextButton(onClick = { deleteCard(editUid) }) { Text("Delete") }
                }
            }
        }
    }

    @Composable
    private fun ActionButton(label: String, value: String) {
        if (editType == value) Button(onClick = { editType = value }) { Text(label) }
        else TextButton(onClick = { editType = value }) { Text(label) }
    }

    @Composable
    private fun SpeakersScreen() {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(speakerMediaId, { speakerMediaId = it }, label = { Text("Media URI / content ID") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(speakerMediaType, { speakerMediaType = it }, label = { Text("Content type") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { refreshAll() }) { Text("Refresh speakers") }

            speakers.forEach { speaker ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(speaker.name, style = MaterialTheme.typography.titleMedium)
                        Text("${speaker.entityId} · ${speaker.state}${speaker.mediaTitle?.let { " · $it" } ?: ""}")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Button(onClick = {
                                haService("media_player", "media_play_pause", JSONObject().put("entity_id", speaker.entityId), "Toggled ${speaker.name}")
                            }) { Text("Play/Pause") }
                            TextButton(onClick = {
                                haService("media_player", "media_stop", JSONObject().put("entity_id", speaker.entityId), "Stopped ${speaker.name}")
                            }) { Text("Stop") }
                            TextButton(onClick = {
                                if (speakerMediaId.isBlank()) message = "Enter a media URI/content ID first"
                                else haService(
                                    "media_player", "play_media",
                                    JSONObject()
                                        .put("entity_id", speaker.entityId)
                                        .put("media_content_id", speakerMediaId)
                                        .put("media_content_type", speakerMediaType.ifBlank { "music" }),
                                    "Sent media to ${speaker.name}",
                                )
                            }) { Text("Send") }
                        }
                    }
                }
            }
            if (speakers.isEmpty()) Text("No Home Assistant media_player entities loaded.")
        }
    }

    @Composable
    private fun SettingsScreen() {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("HexPlayer", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(hexUrl, { hexUrl = it }, label = { Text("HexPlayer URL") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(apiKey, { apiKey = it }, label = { Text("HexPlayer API key") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())

            Text("Home Assistant", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(haUrl, { haUrl = it }, label = { Text("Home Assistant URL") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(haToken, { haToken = it }, label = { Text("Long-lived access token") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())

            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { saveSettings() }) { Text("Save + test") }
                Button(onClick = { provisionHomeAssistant() }) { Text("Provision HA to HexPlayer") }
            }
            Text("Provisioning stores the Home Assistant credentials on the Pi with owner-only file permissions so NFC cards keep working without the phone present.")
        }
    }
}
